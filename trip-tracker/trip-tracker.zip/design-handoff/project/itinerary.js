// Trip data — one row per day: date (YYYY-MM-DD), city, country.
// Replace the rows below with your real table (paste straight from a spreadsheet as CSV),
// or use the "Load your table" panel on the page.
window.TRIP = {
  title: "The Big Europe Trip",
  travellers: "Annalisa & Mitchell",
  // Where the trip starts and ends — drawn on the map, not counted as a stop.
  home: { city: "Wellington", country: "New Zealand", ll: [174.7762, -41.2865] },
  csv: `
date,city,country
2026-09-13,Singapore,Singapore
2026-09-14,Singapore,Singapore
2026-09-15,London,United Kingdom
2026-09-16,London,United Kingdom
2026-09-17,London,United Kingdom
2026-09-18,Paris,France
2026-09-19,Paris,France
2026-09-20,Paris,France
2026-09-21,Paris,France
2026-09-22,Amsterdam,Netherlands
2026-09-23,Amsterdam,Netherlands
2026-09-24,Amsterdam,Netherlands
2026-09-25,Berlin,Germany
2026-09-26,Berlin,Germany
2026-09-27,Berlin,Germany
2026-09-28,Berlin,Germany
2026-09-29,Prague,Czechia
2026-09-30,Prague,Czechia
2026-10-01,Prague,Czechia
2026-10-02,Vienna,Austria
2026-10-03,Vienna,Austria
2026-10-04,Vienna,Austria
2026-10-05,Budapest,Hungary
2026-10-06,Budapest,Hungary
2026-10-07,Budapest,Hungary
2026-10-08,Split,Croatia
2026-10-09,Split,Croatia
2026-10-10,Split,Croatia
2026-10-11,Split,Croatia
2026-10-12,Rome,Italy
2026-10-13,Rome,Italy
2026-10-14,Rome,Italy
2026-10-15,Rome,Italy
2026-10-16,Florence,Italy
2026-10-17,Florence,Italy
2026-10-18,Barcelona,Spain
2026-10-19,Barcelona,Spain
2026-10-20,Barcelona,Spain
2026-10-21,Barcelona,Spain
2026-10-22,Lisbon,Portugal
2026-10-23,Lisbon,Portugal
2026-10-24,Lisbon,Portugal
2026-10-25,Lisbon,Portugal
2026-10-26,Shanghai,China
2026-10-27,Shanghai,China
`
};
